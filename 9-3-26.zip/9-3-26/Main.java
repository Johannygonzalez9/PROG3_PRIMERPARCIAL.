import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    int fila = 1;

    @Override
    public void start(Stage stage) {

        TextField txtNombre = new TextField();
        TextField txtPoder = new TextField();
        TextField txtPlaneta = new TextField();
        TextField txtTecnica = new TextField();
        TextField txtEdad = new TextField();

        ComboBox<String> comboRaza = new ComboBox<>();
        comboRaza.getItems().addAll(
                "Saiyajin",
                "Humano",
                "Namekiano",
                "Androide",
                "Majin",
                "Freezer Race"
        );

        Button btnAgregar = new Button("Agregar");

        GridPane formulario = new GridPane();
        formulario.setPadding(new Insets(10));
        formulario.setHgap(10);
        formulario.setVgap(10);

        formulario.add(new Label("Nombre:"), 0, 0);
        formulario.add(txtNombre, 1, 0);

        formulario.add(new Label("Raza:"), 0, 1);
        formulario.add(comboRaza, 1, 1);

        formulario.add(new Label("Poder:"), 0, 2);
        formulario.add(txtPoder, 1, 2);

        formulario.add(new Label("Planeta:"), 0, 3);
        formulario.add(txtPlaneta, 1, 3);

        formulario.add(new Label("Tecnica:"), 0, 4);
        formulario.add(txtTecnica, 1, 4);

        formulario.add(new Label("Edad:"), 0, 5);
        formulario.add(txtEdad, 1, 5);

        formulario.add(btnAgregar, 1, 6);

        GridPane tabla = new GridPane();
        tabla.setPadding(new Insets(10));
        tabla.setHgap(20);
        tabla.setVgap(10);

        tabla.add(new Label("Nombre"), 0, 0);
        tabla.add(new Label("Raza"), 1, 0);
        tabla.add(new Label("Poder"), 2, 0);
        tabla.add(new Label("Planeta"), 3, 0);
        tabla.add(new Label("Tecnica"), 4, 0);
        tabla.add(new Label("Edad"), 5, 0);

        btnAgregar.setOnAction(e -> {

            String nombre = txtNombre.getText();
            String raza = comboRaza.getValue();
            String planeta = txtPlaneta.getText();
            String tecnica = txtTecnica.getText();
            String poderTxt = txtPoder.getText();
            String edadTxt = txtEdad.getText();

            if (nombre.isEmpty() || planeta.isEmpty() || tecnica.isEmpty() || poderTxt.isEmpty() || edadTxt.isEmpty() || raza == null) {
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("Todos los campos son obligatorios");
                a.show();
                return;
            }

            try {

                int poder = Integer.parseInt(poderTxt);
                int edad = Integer.parseInt(edadTxt);

                if (poder <= 0 || edad <= 0) {
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Edad y poder deben ser mayores que 0");
                    a.show();
                    return;
                }

                Personaje p = new Personaje(nombre, raza, poder, planeta, tecnica, edad);

                tabla.add(new Label(p.getNombre()), 0, fila);
                tabla.add(new Label(p.getRaza()), 1, fila);
                tabla.add(new Label(String.valueOf(p.getNivelPoder())), 2, fila);
                tabla.add(new Label(p.getPlanetaOrigen()), 3, fila);
                tabla.add(new Label(p.getTecnicaEspecial()), 4, fila);
                tabla.add(new Label(String.valueOf(p.getEdad())), 5, fila);

                fila++;

                txtNombre.clear();
                txtPoder.clear();
                txtPlaneta.clear();
                txtTecnica.clear();
                txtEdad.clear();
                comboRaza.setValue(null);

            } catch (NumberFormatException ex) {
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("Poder y edad deben ser numeros");
                a.show();
            }

        });

        VBox root = new VBox(15);
        root.setPadding(new Insets(15));

        Label titulo = new Label("REGISTRO DE PERSONAJES DRAGON BALL Z");
        Label lista = new Label("PERSONAJES REGISTRADOS");

        root.getChildren().addAll(titulo, formulario, lista, tabla);

        Scene scene = new Scene(root, 700, 500);

        stage.setTitle("Dragon Ball Z");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}