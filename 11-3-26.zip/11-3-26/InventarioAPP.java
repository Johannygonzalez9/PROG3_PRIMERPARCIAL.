import javafx.application.Application;
import javafx.collections.*;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class InventarioApp extends Application {

    ObservableList<Producto> productos = FXCollections.observableArrayList();

    @Override
    public void start(Stage stage) {

        TextField txtNombre = new TextField();
        TextField txtPrecio = new TextField();
        TextField txtCantidad = new TextField();

        Button btnAgregar = new Button("Agregar");
        Button btnEliminar = new Button("Eliminar fila");

        TableView<Producto> tabla = new TableView<>();

        TableColumn<Producto, String> colNombre = new TableColumn<>("Nombre");
        TableColumn<Producto, Double> colPrecio = new TableColumn<>("Precio");
        TableColumn<Producto, Integer> colCantidad = new TableColumn<>("Cantidad");

        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        tabla.getColumns().addAll(colNombre, colPrecio, colCantidad);

        productos.add(new Producto("Laptop", 850.00, 5));
        productos.add(new Producto("Mouse", 12.50, 30));
        productos.add(new Producto("Teclado", 35.00, 15));

        tabla.setItems(productos);

        btnAgregar.setOnAction(e -> {

            try {

                String nombre = txtNombre.getText();
                double precio = Double.parseDouble(txtPrecio.getText());
                int cantidad = Integer.parseInt(txtCantidad.getText());

                Producto p = new Producto(nombre, precio, cantidad);
                productos.add(p);

                txtNombre.clear();
                txtPrecio.clear();
                txtCantidad.clear();

            } catch (Exception ex) {
                System.out.println("error");
            }

        });

        btnEliminar.setOnAction(e -> {

            Producto seleccionado = tabla.getSelectionModel().getSelectedItem();

            if (seleccionado != null) {
                productos.remove(seleccionado);
            }

        });

        GridPane form = new GridPane();
        form.setPadding(new Insets(10));
        form.setHgap(10);
        form.setVgap(10);

        form.add(new Label("Nombre:"), 0, 0);
        form.add(txtNombre, 1, 0);

        form.add(new Label("Precio:"), 0, 1);
        form.add(txtPrecio, 1, 1);

        form.add(new Label("Cantidad:"), 0, 2);
        form.add(txtCantidad, 1, 2);
        form.add(btnAgregar, 2, 2);

        VBox root = new VBox(10, form, tabla, btnEliminar);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 500, 400);

        stage.setTitle("Inventario");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}