import java.util.ArrayList;

public class Empresa {

    public static void main(String[] args) {

        ArrayList<Empleado> empleados = new ArrayList<>();

        empleados.add(new EmpleadoTiempoCompleto("Juan", 20000, 5000));
        empleados.add(new EmpleadoTiempoCompleto("Ana", 25000, 3000));
        empleados.add(new EmpleadoMedioTiempo("Luis", 500, 40));
        empleados.add(new EmpleadoMedioTiempo("Maria", 600, 30));

        double totalNomina = 0;

        for (Empleado e : empleados) {
            System.out.println(e);
            totalNomina += e.calcularSalario();
        }

        System.out.println("\nTotal de Nómina: $" + totalNomina);
    }
}