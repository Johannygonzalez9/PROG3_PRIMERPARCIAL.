public class ProductoAlimento extends Producto {

    private String fechaVencimiento;

    public ProductoAlimento(String nombre, double precio, int stock, String fechaVencimiento) {
        super(nombre, precio, stock);
        this.fechaVencimiento = fechaVencimiento;
    }

    public boolean estaProximoAVencer() {
        return fechaVencimiento.contains("02/2026") ||
               fechaVencimiento.contains("03/2026");
    }

    public String obtenerInformacion() {
        return "Producto: " + getNombre() +
                " - Precio: $" + getPrecio() +
                " - Vence: " + fechaVencimiento;
    }
}