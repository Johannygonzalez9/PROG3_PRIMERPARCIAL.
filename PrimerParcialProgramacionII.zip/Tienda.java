import java.util.ArrayList;
import java.util.Scanner;

public class Tienda {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Producto> inventario = new ArrayList<>();

        inventario.add(new ProductoElectronico("Laptop", 1000, 10, 24));
        inventario.add(new ProductoElectronico("Mouse", 25, 20, 6));
        inventario.add(new ProductoElectronico("Teclado", 45, 15, 12));
        inventario.add(new ProductoAlimento("Leche", 2, 30, "15/02/2026"));
        inventario.add(new ProductoAlimento("Pan", 1.5, 50, "10/03/2026"));

        Carrito carrito = new Carrito();

        int opcion;

        do {
            System.out.println("\n=== MENÚ TIENDA ===");
            System.out.println("1. Mostrar productos disponibles");
            System.out.println("2. Agregar producto al carrito");
            System.out.println("3. Ver carrito y total");
            System.out.println("4. Finalizar compra");
            System.out.println("0. Salir");

            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {

                case 1:
                    for (Producto p : inventario) {
                        System.out.println(p.getNombre() +
                                " - Precio: $" + p.getPrecio() +
                                " - Stock: " + p.getStock());
                    }
                    break;

                case 2:
                    System.out.print("Ingrese nombre del producto: ");
                    String nombre = sc.nextLine();

                    System.out.print("Cantidad: ");
                    int cantidad = sc.nextInt();

                    for (Producto p : inventario) {
                        if (p.getNombre().equalsIgnoreCase(nombre)) {
                            try {
                                carrito.agregarProducto(p, cantidad);
                                System.out.println("Producto agregado correctamente.");
                            } catch (StockInsuficienteException e) {
                                System.out.println("Error: " + e.getMessage());
                            }
                        }
                    }
                    break;

                case 3:
                    carrito.mostrarCarrito();
                    break;

                case 4:
                    carrito.mostrarCarrito();
                    System.out.println("Compra finalizada.");
                    opcion = 0;
                    break;

                case 0:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }

        } while (opcion != 0);

        sc.close();
    }
}