public class ProductoElectronico extends Producto {

    private int mesesGarantia;

    public ProductoElectronico(String nombre, double precio, int stock, int mesesGarantia) {
        super(nombre, precio, stock);
        this.mesesGarantia = mesesGarantia;
    }

    public double calcularPrecioConGarantia() {
        if (mesesGarantia > 12) {
            return getPrecio() + 50;
        }
        return getPrecio();
    }

    public String obtenerInformacion() {
        return "Producto: " + getNombre() +
                " - Precio: $" + getPrecio() +
                " - Garantía: " + mesesGarantia + " meses | Verificado";
    }
}