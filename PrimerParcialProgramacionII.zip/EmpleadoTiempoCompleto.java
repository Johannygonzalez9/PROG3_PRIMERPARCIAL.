public class EmpleadoTiempoCompleto extends Empleado {

    private double bono;
    private String codigoVerificacion = "AI_GEN_2026";

    public EmpleadoTiempoCompleto(String nombre, double salarioBase, double bono) {
        super(nombre, salarioBase);
        this.bono = bono;
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase() + bono;
    }

    @Override
    public String toString() {
        return "Empleado Tiempo Completo: " + getNombre() +
                " - Salario Total: $" + calcularSalario();
    }
}