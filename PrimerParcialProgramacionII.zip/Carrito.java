import java.util.ArrayList;

public class Carrito {

    private ArrayList<Producto> productos = new ArrayList<>();
    private ArrayList<Integer> cantidades = new ArrayList<>();

    public void agregarProducto(Producto p, int cantidad) throws StockInsuficienteException {

        if (productos.size() >= 5) {
            System.out.println("El carrito está lleno (máximo 5 productos).");
            return;
        }

        if (cantidad > p.getStock()) {
            throw new StockInsuficienteException("Stock insuficiente para " + p.getNombre());
        }

        productos.add(p);
        cantidades.add(cantidad);
        p.reducirStock(cantidad);
    }

    public double calcularTotal() {

        double total = 0;

        for (int i = 0; i < productos.size(); i++) {
            total += productos.get(i).getPrecio() * cantidades.get(i);
        }

        return total;
    }

    public void mostrarCarrito() {

        System.out.println("=== CARRITO DE COMPRAS ===");

        for (int i = 0; i < productos.size(); i++) {
            System.out.println(productos.get(i).getNombre() +
                    " - Cantidad: " + cantidades.get(i));
        }

        System.out.println("Total: $" + calcularTotal());
    }
}