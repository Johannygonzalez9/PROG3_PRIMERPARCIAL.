public class EmpleadoMedioTiempo extends Empleado {

    private int horasTrabajadas;

    public EmpleadoMedioTiempo(String nombre, double salarioBase, int horasTrabajadas) {
        super(nombre, salarioBase);
        this.horasTrabajadas = horasTrabajadas;
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase() * horasTrabajadas;
    }

    @Override
    public String toString() {
        return "Empleado Medio Tiempo: " + getNombre() +
                " - Salario Total: $" + calcularSalario();
    }
}